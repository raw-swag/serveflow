import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { Response } from 'express';

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();

    const status =
      exception instanceof HttpException
        ? exception.getStatus()
        : HttpStatus.INTERNAL_SERVER_ERROR;

    const exceptionResponse =
      exception instanceof HttpException ? exception.getResponse() : null;

    const message =
      typeof exceptionResponse === 'object' && exceptionResponse !== null
        ? (exceptionResponse as any).message || (exception as any).message
        : (exception as any).message || 'Internal server error';

    response.status(status).json({
      success: false,
      statusCode: status,
      error: exception instanceof HttpException ? exception.name : 'InternalServerError',
      message: Array.isArray(message) ? message.join(', ') : message,
      meta: {
        timestamp: new Date().toISOString(),
      },
    });
  }
}
